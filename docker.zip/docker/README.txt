docker compose
 entrer dans le dossier "docker" ou se trouve le docker-compose

dans le terminal docker 
executer la commande docker-compose up
   

..........DONE